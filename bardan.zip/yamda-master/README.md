# YAMDA DELUXE

Android app for displaying movies using the themoviedb api.

###### The Movie DB Api
- Api key: xxxxxxxxxxxxxxxxxxxxxxxxxxx (Change in ITMDbServiceAPI.java)
- Docs: https://www.themoviedb.org/documentation/api

###### Project Info
- Min API Level: 15

###### TODO:
- Tests and more tests
- Change notifications because some movies don't debut at thursdays

###### Docs
- Documentation was gone :/

Home                       |  Movie Details
:-------------------------:|:-------------------------:
![Home](home.png)          |  ![Movie](movie.png)


